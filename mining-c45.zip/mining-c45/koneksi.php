<?php
/*
 * Configuration Database
 */
return array(
    'host' => "localhost",
    'username' => "root",
    'password' => "",
    'dbname' => "kepribadian_c45",
    // 'port' => "", // sementara menggunakan port bawaan
);

?>
