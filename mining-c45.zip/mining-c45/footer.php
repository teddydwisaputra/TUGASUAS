<!---footer--->

<!---footer--->
<!--copy-->
<div class="copy-section">
    <div class="container">
        <div class="copy-left">
            <p>&copy; 2017 Data Mining Klasifikasi Decision Tree C4.5</p>
        </div>
        <div class="copy-right">
            <p>&reg; Distributed by <a href="http://blogbugabagi.blogspot.com" target="_blank" rel="noopener noreferrer"><b>BlogBugaBagi</b></a></p>
        </div>
       
        <div class="clearfix"></div>
    </div>
</div>
<!--copy-->