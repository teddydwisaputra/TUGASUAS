<div class="banner1">
    <div class="container">
        <h3><a class="btn btn-lg btn-primary" href="login.php">Get Started</a> </h3>
    </div>
</div>
<!--banner-->

<div class="content">
    <!--typography-page -->
    <div class="typo-w3">
        <div class="container">
            <!--<h2 class="tittle">Short Codes</h2>-->
            
            <!--<h3 class="bars">Forms</h3>-->
            <center>
            <h2 class="typoh2">Aplikasi Klasifikasi Karakteristik Kepribadian Manusia</h2>
            <h3 class="typoh2">dengan Metode Decision Tree C4.5</h3><br>
            <p>
            Manusia mempunyai karakter yang berbeda-beda dan unik. Karakter atau kepribadian manusia bisa dipelajari, dan manusia kadang memiliki kesamaan karakter antara satu dengan yang lainnya.
            kepribadian manusia telah dikaji dan dirangkum menjadi empat jenis. Keempatnya masuk dalam teori proto-psikologis, di mana teori itu dibagi lagi menjadi empat tipe kepribadian mendasar, yaitu sanguinis (optimis, aktif dan sosial), koleris (pemarah, cepat atau mudah tersinggung), Kemudian tipe melankolis (analitis, bijak dan tenang), dan Plegmatis ( santai dan damai). Tetapi, ada kemungkinan seseorang memiliki dua karakter.
            </p>
            </center>
        </div>
    </div>
    <!-- //typography-page -->

</div>